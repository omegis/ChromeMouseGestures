/**
 * Mouse Gestures Extension - Popup Script
 * Version: 1.6.0
 * Last Update: 2025-10-12
 */

console.log('Mouse Gestures Extension - Popup');
console.log('Version: 1.6.0');
console.log('Last Update: 2025-10-12');

const enableToggle = document.getElementById('enableToggle');
const debugToggle = document.getElementById('debugToggle');

// Load current state
chrome.storage.sync.get(['gesturesEnabled', 'debugLogging'], (result) => {
  const isEnabled = result.gesturesEnabled !== false; // Default to true
  const debugEnabled = result.debugLogging === true; // Default to false
  enableToggle.checked = isEnabled;
  debugToggle.checked = debugEnabled;
});

// Handle gesture enable/disable toggle
enableToggle.addEventListener('change', (e) => {
  const isEnabled = e.target.checked;

  chrome.storage.sync.set({ gesturesEnabled: isEnabled }, () => {
    console.log('Gestures enabled:', isEnabled);
  });
});

// Handle debug logging toggle
debugToggle.addEventListener('change', (e) => {
  const debugEnabled = e.target.checked;

  chrome.storage.sync.set({ debugLogging: debugEnabled }, () => {
    console.log('Debug logging:', debugEnabled);
  });
});
